package com.axiomsl.hotel.configuration;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

/**
 * Created by Oleg Volkov (AxiomSL) on 12.06.2016.
 *
 * Spring Security Initializer
 */
public class HotelSecurityInitializer extends AbstractSecurityWebApplicationInitializer {
}
