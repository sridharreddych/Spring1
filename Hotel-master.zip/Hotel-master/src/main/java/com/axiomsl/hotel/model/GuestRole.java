package com.axiomsl.hotel.model;

/**
 * Created by Oleg Volkov (AxiomSL) on 12.06.2016.
 *
 * Guest roles enum
 */
public enum GuestRole {
    ROLE_ADMIN,
    ROLE_GUEST
}
