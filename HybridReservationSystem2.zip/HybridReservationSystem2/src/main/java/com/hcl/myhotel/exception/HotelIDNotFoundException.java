package com.hcl.myhotel.exception;

public class HotelIDNotFoundException {
	private static final long serialVersionUID = 1L;

	public HotelIDNotFoundException(String message)
	{
		super();
	}
}
